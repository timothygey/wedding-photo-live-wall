# Seamless Photo Download — Implementation Guide

**For:** home-laptop Claude (VSCode) to apply to `wedding-app`.
**Goal:** make the Live Gallery "Save Photo" trigger the phone's NATIVE
save-to-Photos/Gallery sheet on iOS & Android, across Chrome/Edge/Safari.
Fixes the Safari bug where Download just opened the raw Storage image on a
white page.

---

## Root cause
Old button was `<a href="<firebasestorage URL>" download>`. The HTML
`download` attribute is **ignored for cross-origin URLs**, so browsers just
navigate to the image. (Storage is a different origin than the site.)

## Fix = Hybrid
Fetch the image as a Blob, then:
1. **Web Share API** (`navigator.share({files:[...]})`) → native "Save Image"
   (iOS Photos) / "Save to Gallery/Downloads" (Android). iOS Safari 15+, modern
   Android Chrome/Edge.
2. **Fallback:** same-origin `blob:` URL + `<a download>` (works because blob is
   same-origin) → saves to Downloads/Files.
3. **Last resort:** open image in new tab (long-press → Save).

Requires **CORS** on the Storage bucket so `fetch()` can read the image.

---

## This ZIP already contains the finished edits
Drop these files into the project (overwrite), then do the ONE-TIME CORS step.

| File | Change |
|------|--------|
| `public/js/gallery.js` | New `savePhoto()` handler + `currentPhotoUrl` tracking; removed the anchor href/download logic. |
| `public/gallery.html` | Download `<a>` → `<button id="downloadBtn">⬇️ Save Photo`; CSS `?v=16`, gallery.js `?v=10`. |
| `cors.json` | Bucket CORS config (new file). |

> If applying by hand instead, the key diffs are in the "Manual diffs"
> section below.

---

## REQUIRED one-time step: apply CORS to the bucket
Without this, `fetch()` of the image is blocked and Save silently fails.

Bucket: `wedding-photo-wall-3ace4.firebasestorage.app`

Run from the `wedding-app` folder (needs `gsutil` from Google Cloud SDK, or use
Cloud Shell in the browser):
```bash
gsutil cors set cors.json gs://wedding-photo-wall-3ace4.firebasestorage.app
```
Verify:
```bash
gsutil cors get gs://wedding-photo-wall-3ace4.firebasestorage.app
```

**No gsutil / prefer browser:** open Cloud Shell at
https://console.cloud.google.com (project `wedding-photo-wall-3ace4`), upload
`cors.json`, run the same `gsutil cors set` command.

---

## Deploy
Only hosting changed (plus the one-time CORS above):
```bash
firebase deploy --only hosting
```

---

## Test matrix
Open `/gallery`, tap a photo, tap **Save Photo**:
| Device / browser | Expected |
|------------------|----------|
| iPhone Safari | Native share sheet → **Save Image** → Photos |
| iPhone Chrome | Same native share sheet |
| Android Chrome/Edge | Native share sheet → Save to Gallery/Downloads |
| Desktop Chrome | File downloads (blob fallback) — no share sheet, that's fine |

If Save does nothing on mobile: CORS not applied yet → re-check the gsutil step.

---

## Notes / behavior
- Cost-guard ON: Save button is hidden (unchanged — no full-res egress).
- Blessing cards: no image, so no Save button (unchanged).
- Filename saved as `TimothyMegumi_<id>.jpg`.
- The share-sheet "cancel" is treated as done (no error shown).

---

## Manual diffs (only if NOT using the bundled files)

### gallery.html
```html
<!-- head: -->
<link rel="stylesheet" href="css/styles.css?v=16" />
<!-- actions block: -->
<div class="actions">
  <button class="btn btn-primary" id="downloadBtn" type="button">⬇️ Save Photo</button>
</div>
<!-- script: -->
<script type="module" src="js/gallery.js?v=10"></script>
```

### gallery.js
1. Near the top state vars add:
```js
let currentPhotoUrl = null; // display URL of the photo in the lightbox
```
2. In `openLightbox()` photo branch, replace the `downloadBtn.href/…download` lines:
```js
// guard ON branch:
lightboxImg.src = data.thumbnailURL;
currentPhotoUrl = null;
downloadBtn.style.display = "none";
// guard OFF branch:
lightboxImg.src = data.displayURL;
currentPhotoUrl = data.displayURL;
downloadBtn.style.display = "";
downloadBtn.textContent = "⬇️ Save Photo";
downloadBtn.disabled = false;
```
3. Add the handler (see full code in the bundled `gallery.js`):
```js
downloadBtn.addEventListener("click", savePhoto);
async function savePhoto() {
  if (!currentPhotoUrl || guardLocked) return;
  // fetch blob → navigator.share({files}) → blob <a download> fallback
  // → window.open() last resort. (full body in bundled file)
}
```

That's it — the bundled files are the source of truth; these snippets are just
for reference.
